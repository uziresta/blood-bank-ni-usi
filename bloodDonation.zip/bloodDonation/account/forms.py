from django import forms
from .models import User, Profile

class UserRegistrationForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password']
        widgets = {
            'password': forms.PasswordInput(),
        }

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['first_name', 'last_name', 'weight', 'height', 'region', 'province', 'municipality', 'blood_type', 'availability']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'}),
            'weight': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Weight (kg)'}),
            'height': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Height (cm)'}),
            'region': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Region'}),
            'province': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Province'}),
            'municipality': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Municipality'}),
            'blood_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Blood Type'}),
            'availability': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
