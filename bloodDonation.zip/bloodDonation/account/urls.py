from django.urls import path
from .views import register, home, profile_form, user_login, logout_view, profile_view, ProfileUpdateView

urlpatterns = [
    path('register/', register, name='register'),
    path('login/', user_login, name='login'),
    path('profile-form/', profile_form, name='profile_form'),
    path('profile/', profile_view, name='profile'),
    path('', home, name='home'),
    path('profile/update/', ProfileUpdateView.as_view(), name='profile_update'),
    path('logout/', logout_view, name='logout')
]
