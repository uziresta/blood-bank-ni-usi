from django.contrib import messages
from django.shortcuts import render, redirect
from .models import User, Profile,  BloodDonationRequest
from .forms import UserRegistrationForm, ProfileForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.views import View
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)  # Create a user instance but don't save it yet
            user.set_password(form.cleaned_data['password'])  # Set the password to the hashed version
            user.save()  # Now save the user instance
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')
        else:
            messages.error(request, 'Registration failed. Please check the form for errors.')
    else:
        form = UserRegistrationForm()
    return render(request, 'account/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            next_url = request.POST.get('next', 'home')
            return redirect(next_url)
        else:
            error_message = "Invalid username or password"
            return render(request, 'account/login.html', {'error_message': error_message})
    return render(request, 'account/login.html')

@login_required
def home(request):
    if not hasattr(request.user, 'profile') or request.user.profile is None:
        return redirect('profile_form')
    return render(request, 'account/profile_view.html')

@login_required
def profile_form(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            return redirect('home')
    else:
        form = ProfileForm()

    return render(request, 'account/profile_form.html', {'form': form})


@login_required
def profile_view(request):
    profile = Profile.objects.get(user=request.user)
    blood_requests = BloodDonationRequest.objects.filter(user=request.user)

    return render(request, 'account/profile_view.html', {
        'profile': profile,
        'blood_requests': blood_requests,
    })


class ProfileUpdateView(View):
    def get(self, request):
        profile = Profile.objects.get(user=request.user)
        form = ProfileForm(instance=profile)
        return render(request, 'account/profile_update.html', {'form': form})

    def post(self, request):
        profile = Profile.objects.get(user=request.user)
        form = ProfileForm(request.POST, instance=profile)

        if form.is_valid():
            new_availability = form.cleaned_data['availability']
            last_donation_date = profile.last_donation_date

            if new_availability and last_donation_date:
                days_since_last_donation = (timezone.now().date() - last_donation_date).days

                if days_since_last_donation < 56:
                    remaining_days = 56 - days_since_last_donation
                    messages.error(request, f"You need to wait {remaining_days} more days before changing your availability.")
                    return render(request, 'account/profile_update.html', {'form': form})

            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile_view')

        return render(request, 'account/profile_update.html', {'form': form})

def logout_view(request):
    logout(request)  # Log the user out
    return redirect('login')
