from django.contrib import admin
from django.urls import include, path
from account.views import user_login  # Import the user_login view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', user_login, name='login'),  # Set user_login as the main page
    path('accounts/', include('account.urls')),  # Include account app URLs
]
